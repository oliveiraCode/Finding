//
//  DetailsCollectionViewCell.swift
//  FindingApp
//
//  Created by Leandro Oliveira on 2019-01-19.
//  Copyright © 2019 OliveiraCode Technologies. All rights reserved.
//

import UIKit

class DetailsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageBusiness: UIImageView!
    
}
